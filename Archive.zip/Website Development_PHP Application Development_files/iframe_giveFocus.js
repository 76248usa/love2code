//give canvas the focus
$(window).on('load', function () {
	giveSketchFocus();
});